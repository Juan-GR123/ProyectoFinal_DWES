<h1>Crear nueva Categoria</h1>

<form action="<?=base_url?>/categoria/save" method="POST">
    <label for="">Nombre</label>
    <input type="text" name="nombre">

    <input type="submit" value="Guardar">
</form>