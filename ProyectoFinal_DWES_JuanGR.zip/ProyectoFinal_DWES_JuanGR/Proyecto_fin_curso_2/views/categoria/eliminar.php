<h1>Eliminar Categoria</h1>

<form action="<?=base_url?>/categoria/delete" method="POST">
    <label for="">Nombre</label>
    <input type="text" name="nombre">

    <input type="submit" value="Eliminar">
</form>